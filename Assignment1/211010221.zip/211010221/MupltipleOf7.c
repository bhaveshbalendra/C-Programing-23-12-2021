#include<stdio.h>

int main()
{int num;
printf("Enter the Number:");
scanf("%d",num);

if(num%7==0)
{printf("Yes Number is Multiple of 7");
}
else{
print("No it is not the Multiple of 7");
}
return 0;
}
