clude <stdio.h>
int main() {
   int Num;
   printf("Enter The Number: ");
   scanf("%d", &Num);

   if (Num==1) {
      printf("The Month is January:");
   }
    
	else if (Num==2) {
    printf("The Month is Febuary:");
   }
      else if (Num==3) {
    printf("The Month is March:");
   }
      else if (Num==4) {
    printf("The Month is April:");
   }
     
	    else if (Num==5) {
    printf("The Month is May"); }
   
      else if (Num==6) {
    printf("The Month is june");
    
       else if (Num==7) {
    printf("The Month is july");
	}
	else if (Num==8 {
    printf("The Month is August");
   }
      else if (Num==3) {
    printf("The Month is March:");
   }
      else if (Num==4) {
    printf("The Month is April:");
   }
     
	    else if (Num==5) {
    printf("The Month is May"); }
   
      else if (Num==6) {
    printf("The Month is june");
    
       else if (Num==7) {
    printf("The Month is july");
	}
   
   return 0;
}
