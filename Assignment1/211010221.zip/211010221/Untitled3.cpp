#include<stdio.h>

int main()
{int num;
printf("Enter the Number:");
scanf("%d",num);

if(num%7==0)
{
	if {printf("Yes Number is Multiple of 5 and 3");}
}
else{
print("No it is not the Multiple of 5 and 3");
}
return 0;
}
