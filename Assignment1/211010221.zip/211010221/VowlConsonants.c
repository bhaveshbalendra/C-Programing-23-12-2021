#include<stdio.h>

int main()
{int num;
printf("Enter the Number in Lower Case:");
scanf("%d",num);

if(num==a)
{printf("Word is Vowel");
}
else{
print("Word is Consonant");
}
return 0;
}
